package com.employemanagementsystem.model;


import lombok.*;

@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
@ToString

public class Employee {

    private int employeeId;

    private String employeeFirstName;

    private String employeeLastName;

    private String emailId;

    private String password;

    private int employeeAge;

    private String address;

}
