package com.employemanagementsystem.service;

import com.employemanagementsystem.model.Employee;

import java.util.List;

public interface EmployeeService {

    boolean saveEmployee(Employee employee);

    List<Employee> getAllEmployees();

    Employee getEmployeeBasedOnId(int id);

    boolean updateEmployeeBasedOnId(int id, Employee employee);

    boolean deleteEmployeeById(int id);

    boolean deleteAllEmployee();



}
