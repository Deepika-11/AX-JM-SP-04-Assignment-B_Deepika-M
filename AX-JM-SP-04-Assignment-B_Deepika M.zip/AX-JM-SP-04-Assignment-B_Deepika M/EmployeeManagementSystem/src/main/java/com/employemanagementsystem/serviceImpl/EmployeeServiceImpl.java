package com.employemanagementsystem.serviceImpl;

import com.employemanagementsystem.model.Employee;
import com.employemanagementsystem.service.EmployeeService;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Predicate;
import java.util.stream.Collectors;

@Service
public class EmployeeServiceImpl implements EmployeeService {

    static List<Employee> employeeList = new ArrayList<>();

    @Override

    public boolean saveEmployee(Employee employee) {
       boolean findId = false;
       for(Employee emp : employeeList){
           if(emp.getEmployeeId() == employee.getEmployeeId()){
               findId = true;
           }
       }
       if(!findId){
           employeeList.add(employee);
           return true;
       }
       return false;
    }

    @Override
    public List<Employee> getAllEmployees() {
     //   System.out.println(employeeList);
        return employeeList;
    }

    @Override
    public Employee getEmployeeBasedOnId(int id) {
        for(Employee emp : employeeList){
            if(id == emp.getEmployeeId()){
                return emp;
            }
        }
        return null;
    }

    @Override
    public boolean updateEmployeeBasedOnId(int id, Employee employee) {
        for(Employee emp : employeeList){
            if(id == emp.getEmployeeId()){
                employeeList.remove(emp);
                employeeList.add(employee);
                return true;
            }
        }
        return false;
    }

    @Override
    public boolean deleteEmployeeById(int id) {
        for(Employee emp : employeeList) {
            if (id == emp.getEmployeeId()) {
                employeeList.remove(emp);
                return true;
            }
        }
        return false;
    }

    @Override
    public boolean deleteAllEmployee() {
        if(employeeList.isEmpty()){
            return false;
        }
        employeeList.clear();
        return true;
    }


}
