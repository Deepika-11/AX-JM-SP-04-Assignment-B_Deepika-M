package com.productmanagementsystem;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProductManagementSystemApplicationTests {

	@Test
	void contextLoads() {
	}

}
